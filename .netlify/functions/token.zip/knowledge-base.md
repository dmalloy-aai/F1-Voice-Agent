# 2026 Formula 1 Regulations — Comprehensive Knowledge Base
*For use as a Voice Agent foundational knowledge document*
*Last updated: April 2026 — includes post-season-opening refinements*

---

## Table of Contents

1. [Overview & Philosophy](#overview)
2. [Technical Regulations: Chassis & Dimensions](#chassis)
3. [Technical Regulations: Aerodynamics](#aerodynamics)
4. [Technical Regulations: Power Unit](#power-unit)
5. [Energy Management System](#energy-management)
6. [Tyres](#tyres)
7. [Financial Regulations (Cost Cap)](#financial)
8. [Sporting Regulations](#sporting)
9. [Power Unit Suppliers & Team Alignments](#teams)
10. [2026 Season: Early Races & Issues Identified](#early-season)
11. [April 2026 Regulatory Refinements](#refinements)
12. [Driver Reactions & Expert Commentary](#commentary)

---

## 1. Overview & Philosophy {#overview}

The 2026 Formula 1 season marks the most sweeping regulatory overhaul in the sport's modern era. The changes were developed by the FIA, Formula 1, and all teams over several years, with the primary goals of:

- Producing **smaller, lighter, more agile cars** that are closer to the sport's heritage spirit
- Introducing **all-new hybrid power units** with a near 50/50 split between combustion and electric power
- Replacing the Drag Reduction System (DRS) with **active aerodynamics** as a more elegant and technically integrated solution
- Attracting **new power unit manufacturers** (Ford, Audi, and new entrant Cadillac) to broaden the sport's appeal
- Transitioning to **100% advanced sustainable fuels**
- Improving **wheel-to-wheel racing** and overtaking opportunities

The regulations were officially unveiled by the FIA in 2023 and finalised through 2024. Refinements continued through 2025, with further in-season adjustments announced in April 2026 following feedback from the first three races of the new era.

---

## 2. Technical Regulations: Chassis & Dimensions {#chassis}

### Key Physical Changes

The 2026 cars are significantly smaller than their predecessors in almost every dimension:

- **Wheelbase**: Reduced from a maximum of 3,600mm to 3,400mm — 200mm shorter
- **Width**: Reduced from 2,000mm to 1,900mm — 100mm narrower
- **Minimum weight**: Reduced by approximately 30kg, down to **768kg** (including driver but excluding fuel)
- **Front tyres**: 25mm narrower tread
- **Rear tyres**: 30mm narrower tread

These changes were intentional. The 2022-generation cars, while producing spectacular racing, had grown extremely large and heavy due to the demands of their ground-effect aerodynamic packages. The 2026 cars are designed to feel more like the nimble, driver-focused machines associated with Formula 1's image.

### Safety Improvements

The FIA used the 2026 cycle to introduce several structural safety upgrades:

- A **two-stage nose design** has been introduced to mitigate the risk of nose detachment in frontal impacts. The new design creates an initial crumple zone before the main structure engages, reducing the likelihood of a nose becoming a projectile.
- The **roll structure** has been reinforced to withstand **23% greater loads** than the previous regulations required.
- **Side impact protection** and cockpit safety structures have been updated.

### Construction Philosophy

Cars continue to use carbon fibre monocoque construction. The reduction in size and weight was achieved through a combination of smaller dimensions, revised component specifications, and the removal of certain complex systems (notably the MGU-H from the power unit — see below).

---

## 3. Technical Regulations: Aerodynamics {#aerodynamics}

### The End of Ground Effect Tunnels

The 2022-generation cars used Venturi tunnels under the floor to generate massive downforce through ground effect — a philosophy that made the cars extraordinarily fast but also created unpredictable "porpoising" at high speed and made them very difficult to follow closely in corners. For 2026, those ground effect tunnels have been **removed**. The floor returns to a partially flat design, significantly reducing the amount of aerodynamic downforce generated from underneath the car.

### Simplified Bodywork

The regulations mandate:
- **Simpler front wings** with fewer elements
- **In-washing bargeboards** as the preferred solution for managing front-to-rear airflow
- A general philosophy of reducing the complexity of aero appendages that previous regulations had allowed to proliferate
- **Overall drag reduced by up to 40%** compared to the 2022-generation cars at equivalent downforce levels

### Active Aerodynamics: Corner Mode and Straight Mode

The headline aerodynamic innovation of the 2026 regulations is a mandatory **active aerodynamics system**. Both the front and rear wing elements are moveable, controlled by the car's onboard systems and the driver. There are two primary modes:

**Corner Mode (formerly "Z-Mode")**
This is the high-downforce configuration. At lower speeds — in corners, chicanes, and slow sections — the front and rear wing elements angle to maximum attack, generating maximum grip. This is effectively the "default" aerodynamic state of the car when cornering.

**Straight Mode (formerly "X-Mode")**
This is the low-drag configuration. Above a defined speed threshold on straights, the front and rear wing elements flatten automatically, cutting drag dramatically and allowing the car to reach higher top speeds. The system activates automatically — drivers do not need to press a button as they did with DRS.

The FIA originally used the terms "X-Mode" and "Z-Mode" but determined these were confusing for fans and renamed them "Straight Mode" and "Corner Mode" before the 2026 season started. The transition is seamless and automatic, governed by GPS position on circuit and vehicle speed.

### Why Active Aero Replaces DRS

DRS (Drag Reduction System), used from 2011 to 2025, allowed a following driver within one second of a car ahead to open a flap on the rear wing, reducing drag and gaining a speed advantage of approximately 10-15km/h. While effective at enabling overtaking, DRS was often criticised for making passes feel artificial — a "free" overtake rather than an earned one.

Active aerodynamics is intended to be a more holistic replacement. Because every car's wing automatically flattens on straights, the drag reduction is universal, not just available to the pursuing driver. The overtaking advantage for the chasing driver instead comes from **Overtake Mode** (see Energy Management section).

---

## 4. Technical Regulations: Power Unit {#power-unit}

### Architecture Overview

The 2026 power unit represents the most significant change to Formula 1's engine formula since the 1.6-litre V6 hybrid was introduced in 2014. Key specifications:

- **Engine**: 1.6-litre V6 turbocharged internal combustion engine (ICE) — unchanged from 2014 era
- **Total power output**: Still exceeds **1,000 bhp / ~750kW** combined
- **Power split**: Approximately **50% from the ICE, 50% from the electric motor (MGU-K)**
- **Fuel**: 100% Advanced Sustainable Fuel (a change from 2025 which used a 10% sustainable blend)

### The MGU-K: Massively Enhanced

The Motor Generator Unit — Kinetic (MGU-K) has been fundamentally redesigned:

- **Old MGU-K**: Delivered approximately 120kW (161 bhp) to the rear wheels
- **New MGU-K**: Delivers up to **350kW (469 bhp)** to the rear wheels — nearly **three times** more powerful
- This makes the electric component a genuine primary power source, not just a supplement

### The MGU-H: Removed

One of the most significant changes is the **complete removal of the MGU-H** (Motor Generator Unit — Heat). This was a highly complex component that harvested energy from exhaust gases flowing through the turbocharger, using that energy to both power the turbo and recover electricity for the battery.

The MGU-H was removed because:
- It was extraordinarily expensive to develop and manufacture, creating a high barrier to entry for new manufacturers
- It had limited road relevance — no road car uses an exhaust heat recovery system of this nature
- It added complexity and weight
- Removing it significantly lowers the cost and difficulty of building a competitive power unit

In place of the MGU-H, the turbocharger is now electrically assisted (an e-turbo), with the electrical energy coming from the main battery store rather than harvested exhaust heat.

### Enhanced Energy Recovery System (ERS)

With the MGU-H gone, the ERS relies entirely on the MGU-K for energy recovery. However, its capacity has been significantly enhanced:

- The battery can now be recharged with **twice as much energy per lap** through regenerative braking and lift-and-coast phases compared to the outgoing system
- Maximum energy available per lap from the electrical system is **8MJ** (subsequently reduced to **7MJ** in the April 2026 refinements — see below)

### Sustainable Fuels

For the first time in Formula 1 history, the power units run on **100% Advanced Sustainable Fuel (ASF)**. These fuels are:

- Certified to be carbon neutral on a lifecycle basis
- Derived from sources including carbon capture technology, municipal waste processing, and non-food biomass
- Not derived from crops that compete with food production
- The same specification fuels were trialled in F2 and F3 during 2025 to validate their performance properties

The move to 100% ASF is a key part of Formula 1's wider commitment to becoming Net Zero Carbon by 2030.

### Power Unit Regulations: New Manufacturer Attractiveness

A stated goal of the revised power unit regulations was to make Formula 1 attractive to new manufacturers. The removal of the MGU-H significantly reduced development costs and complexity. The results:

- **Ford** returned to Formula 1 for the first time since 2004 (partnering with Red Bull Powertrains)
- **Audi** entered as a full constructor and power unit manufacturer
- **Honda** returned as a fully-fledged works manufacturer (after a brief quasi-works period)

---

## 5. Energy Management System {#energy-management}

The 2026 regulations introduced a new vocabulary and set of systems around how energy is deployed and managed during a race. This has been one of the most talked-about — and controversial — aspects of the new regulations.

### Superclipping

**Superclipping** is the phenomenon where the MGU-K actively harvests energy from the drivetrain while the driver has their foot flat on the throttle. At the end of long straights, or through high-speed corners, the car can be "super-clipping" — meaning the electric motor is in regeneration mode, physically slowing the car slightly to bank energy for use later in the lap.

From the outside, superclipping creates a visible and audible "clipping" effect as the car's power output fluctuates. It is the primary cause of the "yo-yo" racing effect observed in the first three races of 2026, where cars would slow noticeably on the approach to corners and then surge back to full power.

**Key parameters (pre-Miami refinements):**
- Maximum superclip duration: variable per lap
- Maximum superclip harvest power: 250kW
- Maximum energy per lap: 8MJ

**Key parameters (post-Miami refinements):**
- Maximum superclip duration: reduced to approximately 2-4 seconds per lap
- Maximum superclip harvest power: increased to 350kW (shorter but more intense bursts)
- Maximum energy per lap: reduced to 7MJ

### Boost

**Boost** is a separately defined mode where the MGU-K deploys maximum electrical power to the rear wheels in addition to the ICE output. Boost is available at all times (subject to energy availability) and is what gives the cars their enormous straight-line acceleration.

Boost is distinct from Overtake Mode — Boost is available whenever the driver has energy and wants to use it, while Overtake Mode has specific conditions attached.

### Overtake Mode

**Overtake Mode** (formerly called "Manual Override Mode" before being renamed pre-season) is the direct replacement for DRS as an overtaking tool. Key rules:

- Can **only be activated** when the driver is within **one second** of the car ahead at designated detection points on the circuit
- When activated, it maintains the MGU-K at peak output (350kW) for an extended duration — pushing more power to the rear axle for longer than would otherwise be available
- It is activated by a driver input (button press), unlike Straight Mode which is automatic
- Deployment zones are defined by the FIA for each circuit

The combination of automatic Straight Mode (low drag on straights, applicable to all cars) and selectable Overtake Mode (extra power for the pursuing car) is designed to make overtaking more frequent and more driver-skill-dependent than DRS was.

### The "Yo-Yo Effect" Problem

In the first three races of 2026, the energy management system created a phenomenon journalists and fans dubbed the "yo-yo effect": cars would repeatedly gain and lose ground on each other not because of braking, cornering, or driving skill, but because of their respective battery states.

A car with full battery charge would rapidly close on a slower car ahead, then as its battery depleted it would slow and the gap would grow again. On the next lap, the cycle would repeat. This created a visually confusing and sometimes frustrating spectacle where positions changed frequently but few "real" overtakes were made.

The FIA's April 2026 refinements were specifically designed to address this by reducing the maximum energy per lap (so cars spend less time harvesting aggressively) and shortening superclip durations.

---

## 6. Tyres {#tyres}

Pirelli continues as Formula 1's sole tyre supplier in 2026 under a renewed contract. The 2026 tyres represent a refinement rather than a revolution, maintaining the 18-inch wheel rim diameter introduced in 2022 but reducing overall tyre dimensions to save weight.

### Key Changes

- **Wheel rim diameter**: Unchanged at 18 inches
- **Front tyre tread width**: Reduced by 25mm
- **Rear tyre tread width**: Reduced by 30mm
- **Total front diameter**: Reduced by 15mm
- **Total rear diameter**: Reduced by 10mm
- **Weight saving**: Approximately 4-5kg per car from the smaller tyres

### Compound Range

Pirelli confirmed a revised compound range for 2026:

- **Range**: C1 (hardest) through C5 (softest) — five compounds
- **C6 removed**: The ultra-soft C6 compound, introduced in recent seasons, has been discontinued. Pirelli determined the delta between C5 and C6 was insufficient to justify its inclusion, and the lighter 2026 cars work harder on tyres, making such a soft compound unnecessary
- **Wider performance steps**: Each compound step represents a more consistent and larger performance delta, encouraging greater strategic variation during races

Pirelli motorsport director Mario Isola explained that the narrower 18-inch tyre represents "a good compromise between saving weight and a tyre with characteristics required in 2026." Retaining the 18-inch rim (rather than switching to a smaller diameter) was chosen to give Pirelli the best opportunity to manage tyre overheating in the new era.

### Blanket Temperatures (Revised in April 2026 Refinements)

Following driver feedback about poor performance in wet conditions, the tyre blanket temperatures for **intermediate tyres** were increased as part of the Miami refinements to improve initial grip on track.

---

## 7. Financial Regulations (Cost Cap) {#financial}

### Overview

Formula 1's Financial Regulations, introduced in 2021, continue in 2026 with significant updates to reflect both inflation and the extraordinary investment required for a new car generation.

### Cost Cap: Operations

- **2025 cap**: $135 million USD per team
- **2026 cap**: **$215 million USD** per team
- The increase accounts for the cost of developing and building an entirely new car to new regulations, inflation adjustments, and the inclusion of some previously excluded costs

### Cost Cap: Power Units

A separate, dedicated cost cap applies to power unit manufacturers:

- **2025 cap**: $95 million USD
- **2026 cap**: **$130 million USD**

The PU cap increase reflects the enormous development investment associated with the new power unit formula and the removal of the MGU-H (requiring substantial redesign work).

### What Remains Excluded

The following categories are not counted toward the cost cap:

- Driver salaries
- The salaries of the three highest-paid employees at each team
- Marketing and hospitality costs
- Travel costs
- Infrastructure investments (factory building, upgrades)

### Concessions for New Manufacturers

The FIA announced "concessions" to teams operating with new power units in 2026, acknowledging that Ford/Red Bull, Honda (Aston Martin), and Audi faced a performance disadvantage in the first year of the regulations while established manufacturers like Ferrari and Mercedes had more development lead time. These concessions allow new entrants additional testing and development freedoms.

---

## 8. Sporting Regulations {#sporting}

### 11 Teams — Cadillac's Arrival

The 2026 season marks the first time Formula 1 has had **11 constructor entries** competing since 2016, with the debut of Cadillac (Andretti Global). This has triggered changes to the qualifying format:

**Qualifying Changes:**
- **Q1**: Now 18 minutes in duration (to accommodate more cars). **Six cars** are eliminated at the end of Q1 (previously five)
- **Q2**: Six cars eliminated (previously five)
- **Q3**: The top 10 shootout remains unchanged

### No DRS

DRS has been completely removed from the sporting regulations. Its replacement, Overtake Mode (activated when within one second of the car ahead), is governed by the technical regulations and operated differently — it is a power boost rather than a mechanical drag reduction device.

### Race Starts (Under Review, Miami 2026)

Race starts have been identified as a specific safety concern under the new regulations. The significant difference in acceleration between cars with full battery charge and those with depleted charge at the moment the lights go out created potentially dangerous speed differentials in the opening seconds.

As part of the April 2026 refinements, an enhanced safety mechanism is being tested at Miami:

- A **"low power start detection" system** monitors each car's acceleration immediately after the clutch is released
- Cars detected as having "abnormally low acceleration" will receive an automatic MGU-K deployment burst to ensure minimum acceleration
- A **visual warning system** with flashing lights will alert drivers to dangerous speed differentials on the grid and opening straight

### Sprint Format

Sprint weekends continue in 2026. The format from 2023-2025 (with a separate Sprint Qualifying session on Saturday morning) is maintained.

### Cadillac and Points Allocations

With 22 cars on the grid, the points-paying positions remain the top 10, unchanged. However, the increased grid size means more cars in the lower midfield battle.

---

## 9. Power Unit Suppliers & Team Alignments {#teams}

Five power unit manufacturers supply ten (soon eleven) teams in 2026. The landscape has been completely reshuffled from the 2025 season.

### Mercedes Power Unit
**Teams:** Mercedes (works), McLaren, Williams, Alpine

Mercedes retains the largest customer base. Notably, McLaren — the 2024 Constructors' Champions — remain Mercedes-powered.

### Ferrari Power Unit
**Teams:** Ferrari (works), Haas, Cadillac

Ferrari supplies three teams in 2026. Cadillac is using Ferrari power units and gearboxes as a customer arrangement while the team establishes itself. Cadillac/General Motors have FIA approval to introduce their own in-house power unit from **2029**.

### Red Bull Powertrains / Ford
**Teams:** Red Bull Racing, Racing Bulls (VCARB)

Ford officially returned to Formula 1 power unit development in 2026 for the first time since 2004, when they ended their Jaguar F1 programme. Ford is not manufacturing the entire power unit independently but is a significant development and branding partner for Red Bull Powertrains. Both Red Bull teams use this unit.

### Honda Racing Corporation (HRC)
**Teams:** Aston Martin (works relationship)

Honda returned as a fully-fledged works manufacturer in 2026, exclusively partnering with Aston Martin. The arrangement gives Aston Martin factory-level Honda support. This was a significant coup for Aston Martin, who had previously used Mercedes customer power units.

### Audi Power Unit
**Teams:** Audi (works, formerly Sauber/Alfa Romeo)

Audi completed its takeover of the Sauber Group (formerly operating as Alfa Romeo Racing) and became a full constructor and power unit manufacturer for 2026. This is Audi's first entry as a works Formula 1 constructor.

---

## 10. 2026 Season: Early Races & Issues Identified {#early-season}

The opening three rounds of the 2026 season — in **Australia, China, and Japan** — provided the first real-world test of the new regulations. The results were mixed: exciting racing in some respects, but with clear structural issues that prompted an emergency round of regulatory refinements.

### What Worked

- **Closer racing in corners**: The removal of ground-effect tunnels and the simplified aerodynamics meant cars could follow each other more closely, particularly in slow-speed sections
- **Frequent position changes**: Lap time deltas between cars were smaller, and the energy management dimension meant the order was constantly in flux
- **Lewis Hamilton's performances**: Ferrari's new signing, Lewis Hamilton, was particularly well-suited to managing energy and was vocal in his praise of the new formula
- **Increased overtaking attempts**: The Overtake Mode system generated more attempts to pass than DRS had in the equivalent period of previous seasons

### What Went Wrong

**The Yo-Yo Effect**: As described above, position changes were frequently driven by battery state rather than driving skill. The sight of cars slowing dramatically on straights to harvest energy was widely criticised.

**Excessive Superclipping Noise and Visual**: The audible and visual effect of cars surging and slowing on straights was aesthetically jarring for many fans and commentators.

**Qualifying Anomalies**: The single-lap demands of qualifying proved extremely difficult for drivers to manage. Charles Leclerc was caught out in both China and Japan as his energy management strategy failed in qualifying. "I honestly cannot stand these rules in qualifying," Leclerc said.

**Race Start Safety Concerns**: The variation in MGU-K deployment at race starts created dangerous speed differentials in the opening seconds. Cars with full battery states accelerated significantly faster than those with depleted states.

**Team-Specific Problems:**

- **Aston Martin / Honda**: Described by Sky Sports' Martin Brundle as enduring a "horror show." Despite the signing of legendary designer Adrian Newey and a new works Honda partnership, Aston Martin failed to score a single point in the first three races. The Honda V6 was reported to be down on power and struggling with energy recovery efficiency.
- **Audi**: Consistently qualified reasonably but lost multiple positions at race starts due to the new start dynamics. Often four positions worse off at the end of Lap 1 than at the start of the race.
- **Red Bull / Ford**: Max Verstappen publicly raised concerns about correlation issues between simulation and the actual car's behaviour on circuit.

---

## 11. April 2026 Regulatory Refinements {#refinements}

On **April 20, 2026**, following an online meeting between the FIA, all ten Team Principals, CEOs of all Power Unit Manufacturers, and Formula 1 Management (FOM), a package of regulatory refinements was agreed unanimously by all stakeholders. The meeting was triggered by data gathered from the opening three races.

The FIA described these as "refinements" rather than overhauls — the core architecture of the 2026 regulations remains in place.

### Implementation Timeline

- **From Miami Grand Prix (May 3, 2026)**: The majority of changes take effect immediately
- **Tested at Miami, then formally adopted**: The race start system changes are being trialled first before full adoption

### Change 1: Energy Harvesting Reduction

- **Maximum permitted energy per lap (recharge)**: Reduced from **8MJ to 7MJ**
- **Effect**: Cars harvest less aggressively per lap, reducing the severity and frequency of the yo-yo effect and enabling more consistent flat-out driving on straights

### Change 2: Superclip Duration and Power

- **Maximum superclip duration per lap**: Reduced to approximately **2-4 seconds**
- **Peak superclip power**: Increased from **250kW to 350kW**
- **Effect**: Superclipping events become shorter but more intense. Drivers spend less time in harvesting mode overall, improving the visual and competitive spectacle, while the higher peak power means the energy is recovered quickly when it is harvested.

### Change 3: Alternative Energy Limits for Circuit Types

- The number of races where **alternative, lower energy limits** may apply (to suit circuits with specific characteristics) has been increased from **8 to 12 races per season**
- This gives the FIA and teams more flexibility to adapt energy parameters to individual tracks

### Change 4: Wet Weather ERS Limits

- In wet conditions, **maximum ERS deployment is reduced** to limit torque at the rear wheels and improve car control on low-grip surfaces
- This responds to safety concerns raised after several near-incidents in wet conditions in Japan

### Change 5: Intermediate Tyre Blanket Temperatures

- **Intermediate tyre blanket temperatures** have been increased following unanimous driver feedback
- The original temperatures left intermediate tyres insufficiently warm at the point of fitting, creating a dangerous sliding phase before the tyres reached operating temperature

### Change 6: Rear Light Simplification

- The rear light warning system (used to indicate braking and low-speed moments to following cars) has been simplified
- Fewer distinct light states make the visual cues clearer and more consistent, particularly in conditions of spray or low visibility

### Change 7: Race Start Safety System (Trial at Miami)

- A **"low power start detection" system** will be trialled: if a car's acceleration is detected as "abnormally low" immediately after clutch release, the system triggers an automatic MGU-K deployment to ensure minimum acceleration
- A **visual flashing warning system** in the cockpit will alert drivers to dangerous differentials at starts

### Official Statements

The FIA's official release stated: *"The proposals agreed will be implemented from the Miami Grand Prix, apart from the race start changes that are set to be tested in Miami and adopted following feedback and analysis. These refinements reflect our commitment to continuous improvement and the collaborative relationship between all stakeholders in Formula 1."*

Formula 1's statement echoed this sentiment, noting the changes were the result of data analysis from the first three events and direct consultation with drivers, teams, and manufacturers.

---

## 12. Driver Reactions & Expert Commentary {#commentary}

### Driver Reactions

**Max Verstappen (Red Bull / Ford) — Highly Critical**
Verstappen, the four-time World Champion, was the sport's most vocal critic of the new regulations from the opening race. His comments generated significant media coverage throughout the early season.

*"As a driver, the feeling is not very Formula 1-like. It feels a bit more like Formula E on steroids. A lot of what you do as a driver, in terms of inputs, has a massive effect on the energy side of things. For me, that's just not Formula 1."*

ESPN compiled every specific complaint Verstappen made across the first three races, noting that while some were deemed valid by analysts, others reflected the Red Bull car's specific correlation issues rather than a universal problem with the regulations.

**Lewis Hamilton (Ferrari) — Enthusiastic Supporter**
Hamilton, who joined Ferrari from Mercedes in 2025, has been the most prominent defender of the new era among top drivers.

*"That is how racing should be."* — Said in direct response to criticism of yo-yo racing ahead of the Japanese Grand Prix.

Hamilton has also described the new cars as "the best form of racing I've experienced in 20 years" — a striking claim from someone who raced the ground-breaking 2012-2016 V8-era cars and the dominant 2017-2020 turbo-hybrid era cars.

**Charles Leclerc (Ferrari) — Mixed**
Leclerc delivered the most colourful quote of the new era — in two different contexts.

Struggling in qualifying in China: *"I honestly cannot stand these rules in qualifying."*

Then, in a wheel-to-wheel battle with George Russell during a race, Leclerc radioed his pit wall: *"This is like a mushroom on Mario Kart!"* — referencing the speed-boosting power-up item in the Nintendo game, likening it to Overtake Mode. The quote went viral.

**George Russell (Mercedes) — Cautiously Positive**
Russell has generally been supportive of the new regulations' intent while acknowledging the teething issues.

### Expert Commentary

**Martin Brundle (Sky Sports F1)**
Brundle described Aston Martin's season start as a "horror show" and was clear that the Honda-powered team would not be competitive quickly. He also raised concerns about the artificial nature of position changes under the yo-yo effect, though acknowledged the FIA's response had been admirably swift.

**Peter Windsor (Read Motorsport)**
Windsor was notably critical on a deeper philosophical level: *"The new F1 regulations are erasing what makes Leclerc and Verstappen elite."* His argument was that the computational demands of energy management software and automated systems were reducing the premium placed on raw driver talent in favour of car setup and software optimisation.

**The Race Analysis**
The Race, in a widely shared piece, described the first three races as leaving "a deeply disturbing impression" and characterised the yo-yo effect as fundamentally incompatible with what most fans understand racing to be. However, they were broadly positive about the FIA's willingness to act quickly and noted that the April refinements addressed the most serious structural issues.

**Motorsport Magazine**
Motorsport Magazine raised concerns about race starts specifically before the season began, calling them "a problem waiting to happen." Their pre-season analysis proved accurate and the FIA's Miami start-safety trial was seen as a vindication of this analysis.

**General Consensus**
Most expert opinion as of April 2026 falls into a cautious middle ground: the 2026 regulations have real merit — closer racing, better aerodynamic overtaking potential, a fascinating technical formula, and successful attraction of new manufacturers — but the energy management system in its original form created a spectacle problem that needed fixing. The April 2026 refinements are widely seen as a necessary and positive step, but most analysts believe further iteration will be required through the season.

---

## Quick Reference: Key Numbers

| Parameter | Value |
|---|---|
| Wheelbase | 3,400mm (down from 3,600mm) |
| Car width | 1,900mm (down from 2,000mm) |
| Minimum weight (with driver) | 768kg |
| Total power output | ~1,000+ bhp |
| ICE / Electric power split | ~50% / 50% |
| MGU-K output | 350kW (469 bhp) |
| Energy per lap (post-Miami) | 7MJ maximum |
| Superclip duration (post-Miami) | ~2-4 seconds per lap |
| Overtake Mode activation | Within 1 second of car ahead |
| Cost cap (operations) | $215 million USD |
| Cost cap (power unit) | $130 million USD |
| Grid size | 22 cars (11 constructors) |
| Tyre rim diameter | 18 inches (unchanged) |
| Fuel type | 100% Advanced Sustainable Fuel |
| Power unit manufacturers | 5 (Mercedes, Ferrari, Red Bull/Ford, Honda, Audi) |

---

## Key Terminology Glossary

**Active Aerodynamics** — The system by which front and rear wing elements move automatically (and on driver command) to optimise either downforce (Corner Mode) or drag reduction (Straight Mode).

**Boost** — The driver-controlled deployment of maximum MGU-K power, available whenever sufficient battery energy is stored. Not subject to proximity-to-car-ahead restrictions.

**Corner Mode** — The high-downforce, high-drag aerodynamic configuration used through slow sections and corners. Activates automatically at lower speeds.

**ERS (Energy Recovery System)** — The system that recovers kinetic energy under braking and during lift-and-coast phases, storing it in the battery for later deployment.

**MGU-K (Motor Generator Unit — Kinetic)** — The electric motor connected to the drivetrain. Delivers up to 350kW in 2026. Also acts as a generator during energy recovery.

**MGU-H (Motor Generator Unit — Heat)** — Removed for 2026. Previously recovered energy from exhaust gases flowing through the turbocharger. Its removal significantly simplified the power unit.

**Overtake Mode** — A driver-activated power boost mode that can only be used when within one second of the car ahead at a detection point. Replaces DRS conceptually.

**Straight Mode** — The low-drag, reduced-downforce aerodynamic configuration that activates automatically on straights above a defined speed threshold.

**Superclipping** — The phenomenon where the MGU-K harvests energy from the drivetrain while the driver is at full throttle, creating a momentary reduction in acceleration. Occurs at the end of straights or in high-speed corners.

**Sustainable Fuel (ASF)** — 100% Advanced Sustainable Fuel used in all 2026 F1 power units. Certified carbon neutral on a lifecycle basis, sourced from waste materials, carbon capture, and non-food biomass.

**Yo-Yo Effect** — The pattern observed in the first three races of 2026 where cars would rapidly close on and then drop away from each other on straights, driven by differences in battery state rather than driver inputs or car performance differences.

---

*Sources used in the compilation of this document:*
- Formula 1 Official (formula1.com) — Regulations explained series, 2026 terminology, refinements announcement
- FIA Official (fia.com) — Technical regulations documents, refinements announcement
- The Race — Early season analysis, regulations fixes explained
- Motorsport.com — Terminology, team alignments, driver commentary
- Sky Sports F1 — Driver reactions, Aston Martin analysis, Miami rule changes
- ESPN — Verstappen complaints analysis, good/bad/ugly 2026 regulations review
- Motorsport Technology — Power unit deep dives
- Pirelli Official — Tyre specifications and compound range
- Williams F1 Official — Regulations summary, Miami changes announcement
- McLaren Official — Regulations explained
- Mercedes-AMG F1 Official — Power unit facts and stats
- Crash.net — Regulations changes, superclipping explained
- Motorsport Week — Refinements announced, changes explained
- Planet F1 — PU suppliers, Miami changes
- The-Race.com — 2026 team weaknesses, early season issues

---

## 2026 Season — Driver & Team Lineup {#lineup}

| Team | Car | Engine | Driver 1 | # | Driver 2 | # |
|---|---|---|---|---|---|---|
| Mercedes-AMG Petronas | W17 | Mercedes | George Russell | 63 | Kimi Antonelli | 12 |
| Scuderia Ferrari | SF-26 | Ferrari | Charles Leclerc | 16 | Lewis Hamilton | 44 |
| McLaren F1 Team | MCL40 | Mercedes | Lando Norris | 4 | Oscar Piastri | 81 |
| Oracle Red Bull Racing | RB22 | Ford/Red Bull | Max Verstappen | 33 | Isack Hadjar | 6 |
| Aston Martin Aramco | AMR26 | Honda | Fernando Alonso | 14 | Lance Stroll | 18 |
| BWT Alpine F1 Team | A526 | Mercedes | Pierre Gasly | 10 | Franco Colapinto | 43 |
| Atlassian Williams Racing | FW48 | Mercedes | Alexander Albon | 23 | Carlos Sainz Jr. | 55 |
| MoneyGram Haas F1 Team | VF-26 | Ferrari | Esteban Ocon | 31 | Oliver Bearman | 87 |
| Visa Cash App Racing Bulls | VCARB 03 | Ford/Red Bull | Liam Lawson | 30 | Arvid Lindblad | 5 |
| Cadillac F1 Team | MAC-26 | Ferrari | Sergio Pérez | 11 | Valtteri Bottas | 77 |
| Audi F1 Team | R26 | Audi | Nico Hülkenberg | 27 | Gabriel Bortoleto | 5 |

**Key entry notes:**
- Cadillac is the 11th team — first new constructor since 2016. MAC-26 named after Mario Andretti Cadillac.
- Audi entered as a full works team after acquiring Sauber; the R26 runs Audi's own power unit.
- Verstappen reverted to #33 after losing #1 to 2025 champion Lando Norris.
- Ford returned to F1 for the first time since 2004, supporting Red Bull Powertrains.
- Honda entered an exclusive works agreement with Aston Martin.
- Alpine switched from Renault to Mercedes power units for 2026.

---

## 2026 Season — Race Calendar {#calendar}

Original 24-race calendar reduced to 22 after Bahrain and Saudi Arabia were cancelled due to the 2026 Iran–Gulf conflict.

| Rd | Grand Prix | Circuit | Date | Status |
|---|---|---|---|---|
| 1 | Australian GP | Albert Park, Melbourne | March 8 | Completed |
| 2 | Chinese GP | Shanghai | March 15 | Completed (Sprint) |
| 3 | Japanese GP | Suzuka | March 29 | Completed |
| — | Bahrain GP | — | April 12 | CANCELLED |
| — | Saudi Arabian GP | — | April 19 | CANCELLED |
| 4 | Miami GP | Miami International Autodrome | May 3 | Upcoming (Sprint) |
| 5 | Canadian GP | Circuit Gilles Villeneuve | May 24 | Sprint |
| 6 | Monaco GP | Circuit de Monaco | June 7 | — |
| 7 | Spanish GP | Barcelona | June 14 | — |
| 8 | Austrian GP | Red Bull Ring | June 28 | — |
| 9 | British GP | Silverstone | July 5 | Sprint |
| 10 | Belgian GP | Spa-Francorchamps | July 19 | — |
| 11 | Hungarian GP | Hungaroring | July 26 | — |
| 12 | Dutch GP | Zandvoort | August 23 | Sprint |
| 13 | Italian GP | Monza | September 6 | — |
| 14 | Spanish GP (Madrid) | Madrid Street Circuit | September 13 | DEBUT |
| 15 | Azerbaijan GP | Baku City Circuit | September 26 | — |
| 16 | Singapore GP | Marina Bay | October 11 | Sprint |
| 17 | United States GP | COTA, Austin | October 25 | — |
| 18 | Mexico City GP | Autódromo Hermanos Rodríguez | November 1 | — |
| 19 | São Paulo GP | Interlagos | November 8 | — |
| 20 | Las Vegas GP | Las Vegas Strip Circuit | November 21 | — |
| 21 | Qatar GP | Lusail | November 29 | — |
| 22 | Abu Dhabi GP | Yas Marina | December 6 | — |

---

## 2026 Season — Race Results {#results}

### Round 1 — Australian Grand Prix (March 8, Albert Park)

**Pole:** George Russell (Mercedes) — 1:18.518

| Pos | Driver | Team | Gap |
|---|---|---|---|
| 1 | George Russell | Mercedes | 1:23:06.801 |
| 2 | Kimi Antonelli | Mercedes | +2.974s |
| 3 | Charles Leclerc | Ferrari | +15.519s |
| 4 | Lewis Hamilton | Ferrari | +16.144s |
| 5 | Lando Norris | McLaren | +51.741s |
| 6 | Max Verstappen | Red Bull | +54.617s |
| 7 | Oliver Bearman | Haas | +1 Lap |
| 8 | Arvid Lindblad | Racing Bulls | +1 Lap |
| 9 | Gabriel Bortoleto | Audi | +1 Lap |
| 10 | Pierre Gasly | Alpine | +1 Lap |
| DNF | Fernando Alonso | Aston Martin | Lap 21 — vibrations |
| DNS | Oscar Piastri | McLaren | Reconnaissance lap crash — unexpected MGU-K power surge |
| DNS | Nico Hülkenberg | Audi | Hydraulic failure before start |

**Fastest Lap:** Max Verstappen (Red Bull) — 1:21.980

**Key events:** Mercedes 1-2; Verstappen started last after crashing on his first Q1 flying lap (rear wheels locked under braking). Three VSC periods. Audi scored points on debut (Bortoleto P9). First Mercedes 1-2 since Las Vegas 2024. Piastri DNS after crashing on the out-lap from an unexpected power surge from the new MGU-K.

---

### Round 2 — Chinese Grand Prix (March 15, Shanghai) — Sprint Weekend

**Sprint pole:** Kimi Antonelli | **GP pole:** Kimi Antonelli — 1:32.064

**Sprint Race Result:** 1. Russell, 2. Leclerc (+0.674s), 3. Hamilton (+2.554s), 4. Norris, 5. Antonelli (10s penalty for Lap 1 collision with Hadjar)

**Grand Prix:**

| Pos | Driver | Team | Gap |
|---|---|---|---|
| 1 | Kimi Antonelli | Mercedes | Winner |
| 2 | George Russell | Mercedes | +5.515s |
| 3 | Lewis Hamilton | Ferrari | +25.267s |
| 4 | Charles Leclerc | Ferrari | — |
| DNS | Lando Norris | McLaren | Battery failure (ICE/hybrid comms) |
| DNS | Oscar Piastri | McLaren | Failed to restart on grid — separate battery fault |

**Fastest Lap:** Kimi Antonelli — 1:35.275

**Key events:** McLaren suffered catastrophic double DNS — two separate Mercedes HPP battery failures, distinct in nature. First time in Norris's 8-season career he missed a race start. Hamilton finished P3 — his first podium in Ferrari colours after a 477-day wait. Antonelli (19 years, 202 days) became the youngest F1 pole-sitter in history (breaking Vettel's 2008 record) and second-youngest grand prix winner in history. First Italian to win a grand prix since Fisichella at the 2006 Malaysian GP.

---

### Round 3 — Japanese Grand Prix (March 29, Suzuka)

**Pole:** Kimi Antonelli

| Pos | Driver | Team | Gap |
|---|---|---|---|
| 1 | Kimi Antonelli | Mercedes | Winner |
| 2 | Oscar Piastri | McLaren | +13.722s |
| 3 | Charles Leclerc | Ferrari | +15.270s |
| 4 | George Russell | Mercedes | +15.754s |
| 5 | Lando Norris | McLaren | +23.479s |
| 6 | Lewis Hamilton | Ferrari | +25.037s |
| 7 | Pierre Gasly | Alpine | +32.340s |
| 8 | Max Verstappen | Red Bull | +32.677s |
| 9 | Liam Lawson | Racing Bulls | +50.180s |
| 10 | Esteban Ocon | Haas | +51.216s |
| DNF | Oliver Bearman | Haas | Lap 20 — 50G crash at Spoon Curve |
| DNF | Lance Stroll | Aston Martin | Lap 30 — water pressure failure |

**Fastest Lap:** Kimi Antonelli — 1:32.432 (Lap 49)

**Key events:** Bearman's 50G crash at Spoon Curve — he encountered Colapinto's Alpine with a ~50 km/h speed differential due to one car deploying MGU-K boost and the other harvesting. Bearman was pushed onto the grass at ~190 mph. He walked away unhurt. Verstappen started P20 (another qualifying incident) and recovered to P8. Safety car deployed Lap 20 after Bearman crash; Antonelli pitted and retained lead. Antonelli became first teenager to win back-to-back F1 races and youngest championship leader in history at 19 years, 216 days. Italy's first championship leader since Ascari in 1953.

---

## 2026 Season — Championship Standings {#standings}

*After Round 3 — Japanese Grand Prix*

### Drivers' Championship

| Pos | Driver | Team | Points |
|---|---|---|---|
| 1 | Kimi Antonelli | Mercedes | 72 |
| 2 | George Russell | Mercedes | 63 |
| 3 | Charles Leclerc | Ferrari | 49 |
| 4 | Lewis Hamilton | Ferrari | 41 |
| 5 | Lando Norris | McLaren | 25 |
| 6 | Oscar Piastri | McLaren | 21 |
| 7 | Oliver Bearman | Haas | 17 |
| 8 | Pierre Gasly | Alpine | 15 |
| 9 | Max Verstappen | Red Bull | 12 |
| 10 | Liam Lawson | Racing Bulls | 10 |
| 11 | Arvid Lindblad | Racing Bulls | 4 |
| 12 | Isack Hadjar | Red Bull | 4 |
| 13 | Gabriel Bortoleto | Audi | 2 |
| 14 | Carlos Sainz | Williams | 2 |
| 15 | Esteban Ocon | Haas | 1 |
| 16 | Franco Colapinto | Alpine | 1 |
| — | Pérez, Bottas, Albon, Alonso, Stroll, Hülkenberg | — | 0 |

### Constructors' Championship

| Pos | Team | Points |
|---|---|---|
| 1 | Mercedes | 135 |
| 2 | Ferrari | 90 |
| 3 | McLaren | 46 |
| 4 | Haas | 18 |
| 5 | Alpine | 16 |
| 6 | Red Bull | 16 |
| 7 | Racing Bulls | 14 |
| 8 | Audi | 2 |
| 9 | Williams | 2 |
| 10 | Cadillac | 0 |
| 11 | Aston Martin | 0 |

---

## 2026 Season — Key Incidents & Storylines {#incidents}

### The Bearman/Colapinto Speed Differential Crash (Japan, Lap 20)
The defining safety incident of the early season. The 2026 power units require drivers to alternate between "deployment" (full MGU-K boost) and "harvesting" (energy recovery, causing significant deceleration). At Suzuka's Spoon Curve, Bearman (deploying) encountered Colapinto's Alpine (harvesting) at a closing speed of ~50 km/h. Bearman was pushed onto the grass at ~190 mph and hit barriers at 50G. He walked away unhurt. Drivers had formally warned FIA stewards about this issue the Friday before the race. Verstappen post-race: "These cars are not correct. It's super frustrating. You have absolutely no idea what the guy in front is doing at any given moment." Toto Wolff: "This cannot happen again." FIA held emergency meetings April 9, 15, 16, 20; result: MGU-K boost button capped at 150 kW (from 350 kW) from Miami onwards.

### McLaren's China Double DNS
Both McLarens failed to start the Chinese GP — the first time any team suffered a double DNS in modern F1. Two separate Mercedes HPP battery failures: Norris lost ICE-hybrid comms, Piastri's battery failed to restart. First time in Norris's 8-season career he missed a race start. McLaren admitted they are "on the back foot" understanding the new 2026 power unit compared to the works Mercedes team.

### Bahrain and Saudi GP Cancellations
F1 confirmed both Middle East rounds cancelled following the Iran–Gulf conflict. Gulf states were struck by Iranian attacks in retaliation for US-Israeli airstrikes. Calendar dropped from 24 to 22 races, creating a five-week gap (March 29 to May 3).

### Mercedes Intra-Team Tension
With Antonelli (72 pts) leading Russell (63 pts), team boss Toto Wolff issued a pointed warning: "The team is always bigger than the drivers. The moment a driver feels like this is all about him, that's not the mindset I would ever allow or accept. If you are selfish and put our joint success at risk, or damage our brand, then I'm going to be ruthless about it."

### Italian Tax Authority Investigation — All 20 Drivers
The Guardia di Finanza (Bologna) launched a tax evasion investigation covering all 20 drivers. Italian law treats F1 drivers as self-employed at Italian circuits; teams are responsible for withholding local tax. Authorities allege teams have failed to remit this tax since at least 2020, potentially hundreds of millions of euros. Criminal charges possible; all 20 drivers received letters requesting tax returns for 2025.

### Piastri's Reconnaissance Lap Crash — Australia
Piastri crashed his MCL40 on the out-lap to the grid before Australia even started — an unexpected MGU-K power surge pushed the car beyond control. He did not start; a brand-new chassis was destroyed on the new regs' first race weekend.

### Verstappen's Qualifying Struggles
Two-time (or more) champion Verstappen started last in both Australia (crashed on first Q1 flying lap at Turn 1 — rear wheels locked under braking with the ABS-less 2026 system) and Japan (another qualifying incident). His best result is P6 in Australia from the back of the grid. Currently 9th in the championship, 60 points off the leader. Quote: "I'm not having fun at all."

---

## 2026 Season — Driver Form & Performance {#form}

### Overperforming / Surprises

**Kimi Antonelli (Mercedes):** The story of the season. 19 years old, two wins (China, Japan), championship leader. Youngest F1 pole-sitter ever (broke Vettel's 2008 record). First teenager with back-to-back wins. Youngest championship leader in history at 19 years, 216 days. Italy's first title contender since Ascari 1953. Calm, methodical, devastatingly fast — his charge from 6th on Lap 1 at Suzuka to race win was the moment of the season so far.

**George Russell (Mercedes):** Won Australia, strong consistency across all three rounds. Experienced head of the championship-leading team, now being pushed hard by his 19-year-old teammate.

**Lewis Hamilton (Ferrari):** P4 Australia, P3 China (first Ferrari podium after 477-day wait), P6 Japan. Said he was "massively excited for new beginnings" and described a conscious reset at Ferrari. Showing he remains competitive at 41 in an entirely new technical era.

**Oliver Bearman (Haas):** P7 Australia (points for the midfield team), strong pace before his Japan crash. A genuine surprise package in the Haas.

**Gabriel Bortoleto (Audi):** P9 on debut in Australia. Audi scored points in their first race — historically rare for any new entrant.

### Underperforming / Struggling

**Max Verstappen (Red Bull):** The dominant force of 2023–2025 is having a nightmare start. Zero qualifying laps completed in Australia (crashed on his first one). Started last twice. Best result: P6 from last in Australia. P9 in championship on 12 points, 60 off the leader. The RB22 chassis is a fundamental problem — poor rear-end balance, hard to set up. Red Bull's own admission: "one second off" the leaders per lap.

**Lando Norris (McLaren):** Defending champion is 5th with 25 points but two of three weekends were heavily compromised. China DNS (battery failure). The MCL40 has genuine pace but reliability is a crisis.

**Fernando Alonso (Aston Martin):** DNF Australia (Lap 21, Honda vibrations). Zero points in three rounds. The Adrian Newey partnership is yet to produce any results — Honda's PU vibration issue with the AMR26 is a fundamental design problem.

**Aston Martin broadly:** Worst-performing team on the grid, zero points. Honda vibrations causing repeated battery failures. Even slower than Cadillac (the brand-new 11th team). ADUO relief mechanism granted; team not expected to be competitive until at least Monaco.

---

## 2026 Season — Technical Picture {#technical}

### Power Unit Hierarchy (as of April 2026)
1. **Mercedes** — dominant in power and energy management
2. **Ferrari** — competitive, strong mechanical package
3. **Ford/Red Bull Powertrains** — broadly competitive but RB22 chassis is a liability
4. **Audi** — new manufacturer, expected development trajectory; showed promise with Bortoleto P9 on debut
5. **Honda (Aston Martin)** — crisis. Violent vibrations when fitted to AMR26 chassis. Battery failures. Power output below competitors. Honda: "extremely challenging."

### Ferrari Miami Upgrade Package
Ferrari bringing ~50% new components to Miami GP — largest single upgrade by any team in 2026 so far. Reworked front wing, new diffuser, revised floor, updated rear wing, suspension adjustments. Target: close the estimated 0.3–0.5s per lap gap to Mercedes.

### Red Bull RB22
Laurent Mekies admitted "significant shortcomings" after China. Poor rear-end balance, hard to set up, chassis doesn't suit the active aero effectively. Ford/Red Bull PU is broadly competitive but the car is the problem. "One second off" leaders per lap.

### McLaren MCL40
Third-best pace in the field when reliable. Mercedes HPP knowledge gap vs. works team is the core problem — exposed by two different battery failure modes on the same race weekend in China.

### ADUO — Additional Development and Upgrade Opportunities
New 2026 in-season mechanism for lagging PU manufacturers:
- Trailing leader by 2–4%: 1 upgrade window
- Trailing leader by >4%: 2 upgrade windows
Honda (Aston Martin) confirmed eligible; ADUO window expected around Monaco GP.

### MGU-K Boost Cap (effective Miami GP)
FIA reduced the maximum MGU-K deployment rate from 350 kW to 150 kW following the Bearman crash and emergency review. Addresses peak speed differentials. Concerns remain about "passive harvesting deceleration" which is harder to regulate.

---

## F1 Basics — For People New to the Sport {#basics}

*This section is for newcomers who want to understand Formula 1 before getting into the 2026-specific regulations.*

### What is Formula 1?

Formula 1 is the highest class of single-seater motor racing in the world. It's the pinnacle of motorsport — the fastest, most technologically advanced, and most expensive form of racing on the planet. Eleven teams compete in 2026, each running two cars — ten established teams plus Cadillac, who joined as the first new constructor since 2016. There are 22 races across a season, held on circuits around the world, from street circuits in Monaco and Las Vegas to purpose-built tracks like Silverstone and Suzuka.

The "Formula" in the name refers to the rulebook — a set of technical and sporting regulations that all cars must comply with. That rulebook is what we're here to talk about.

### Who runs Formula 1?

Formula 1 is owned commercially by Liberty Media (an American company that bought it in 2017). The FIA — Fédération Internationale de l'Automobile — is the governing body that writes and enforces the rules. Teams and drivers must be licensed by the FIA. The FIA also appoints the stewards who make on-track decisions.

### How does a race work?

A Formula 1 weekend typically spans three days — Friday practice, Saturday qualifying, Sunday race. Qualifying determines the starting grid: fastest qualifier starts at the front (called "pole position"). The race itself is usually around 300 kilometres, which takes roughly 1.5 to 2 hours.

Cars must complete a minimum number of pit stops to change tyres — the sport requires teams to use at least two different tyre compounds during the race. Strategy around when to stop, which tyres to use, and how long to stay out is a huge part of racing. Overtaking happens both on-track and through the "undercut" — pitting early to gain track position.

Points are awarded to the top 10 finishers: 25, 18, 15, 12, 10, 8, 6, 4, 2, 1. An extra point goes to the driver who sets the fastest lap (if they finish in the top 10).

### What are constructors?

Each team in F1 is called a "constructor" — because they construct (build) their own car. A constructor earns points from both of its drivers. So if a team's two cars finish 1st and 2nd, they score 43 points. At the end of the season, the team with the most points wins the Constructors' Championship. Drivers individually compete for the Drivers' Championship.

These are the two separate titles in F1: one for the best driver, one for the best team.

### What is a power unit?

The engine in an F1 car is called the power unit. Since 2014, F1 has used hybrid power units — they combine a traditional internal combustion engine with electric motors that recover energy from braking and exhaust heat. In 2026, the hybrid system was redesigned to produce roughly 50% of total power electrically. The power unit is one of the most complex pieces of engineering in the world.

Teams either build their own power unit (Mercedes, Ferrari, Honda/Aston Martin, Renault/Alpine historically, now Audi and Ford/Red Bull) or buy one from a manufacturer. Customer teams pay for a supply deal and get the same hardware — but often not the same software or development pace.

### What is DRS? (Was — it's gone in 2026)

DRS stood for Drag Reduction System. From 2011 to 2025, cars had a movable rear wing flap that could be opened to reduce aerodynamic drag and increase straight-line speed, making overtaking easier. It was only allowed in designated "DRS zones" on the circuit, and only when a driver was within one second of the car ahead.

DRS was controversial — many felt it made overtaking too artificial and easy, removing the skill of defending. The 2026 rules replaced DRS entirely with a new active aerodynamics system that operates across the whole lap, not just in overtaking zones. More on that in the technical regulations sections.

### Why did the rules change for 2026?

Several reasons:

1. The cars had become too big and too heavy. Modern F1 cars in 2025 were around 798kg and nearly 2 metres wide — fans and drivers agreed they'd grown unwieldy.
2. The hybrid system (introduced in 2014) was due for a fundamental redesign. F1 wanted a much bigger electric component to stay relevant to road car manufacturers and sustainability goals.
3. Audi and Ford/Red Bull both committed to F1 under the promise of the 2026 power unit rules. Attracting new manufacturers required new regulations.
4. The sport wanted to move to 100% sustainable fuels (not electric, but synthetic fuels that can run in combustion engines with a near-zero carbon footprint).
5. The DRS system had been a source of criticism. The new active aero was designed as a more elegant solution.

### Key glossary

**Pole position** — Starting at the front of the grid, earned by the fastest qualifier.

**Pit stop** — When a car comes into the pit lane (a road running alongside the main straight) to change tyres or make repairs. A stop typically takes 2–3 seconds for the tyre change alone.

**Safety Car** — A road car (currently a Mercedes AMG) that comes out when there's an incident on track, slowing all cars down and bunching up the field. Drivers can't overtake during a Safety Car period. A Virtual Safety Car (VSC) is a slower-speed limit imposed electronically without a physical car.

**Parc fermé** — A French term meaning "closed park." After qualifying, cars are placed in parc fermé conditions — teams cannot make significant changes to the car setup before the race.

**Undercut** — A pit stop strategy where you pit slightly earlier than a rival, get fresh tyres, and then lap fast enough that when they pit, you come out ahead of them.

**Overcut** — The opposite — you stay out longer than a rival on old tyres, hoping track position and their inlap/outlap time means you come out ahead.

**MGU-K** — Motor Generator Unit – Kinetic. The electric motor that recovers energy from braking and deploys it as extra power out of corners. In 2026 it can produce up to 350kW (reduced to 150kW after safety changes).

**Active aerodynamics** — In 2026, cars have movable aerodynamic surfaces (not just a rear flap) that change shape depending on speed. High drag and downforce through corners, low drag on straights. Controlled automatically by the car.

**Constructor** — A team that builds its own car. Used interchangeably with "team" in modern F1.

**FIA** — Fédération Internationale de l'Automobile. The governing body of world motorsport. They write the rules, police them, and issue penalties.

**Stewards** — Race officials who investigate incidents and issue penalties (like time penalties or grid drops) if a driver breaks the rules.

**Cost cap** — A limit on how much each team can spend per year. Introduced in 2021. In 2026, the cap is set at $145 million for most teams, with adjustments for smaller teams.

**Sprint** — A shorter race (about 100km) held on Saturday at select rounds instead of standard qualifying. Points are awarded, but fewer than in the main race.

**Compound** — The type of tyre being used. Pirelli supplies five compounds ranging from softest (fastest but wears quickly) to hardest (slower but lasts longer). In a race, teams must use at least two different compounds.
